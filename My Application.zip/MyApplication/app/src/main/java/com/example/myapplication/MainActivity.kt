package com.example.myapplication


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                ) {
                    DisplayImages()
                    GreetingText(message = "MyCard", from = "Simone Salvatore La Milia")
                }
            }
        }
    }
}



@Composable
fun GreetingText(message: String, from: String, modifier: Modifier = Modifier) {
    Column ( verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier
        .padding(8.dp)
        .fillMaxSize()

    ){
        GreetingImage()
        Text(
                text = message,
                fontSize = 50.sp,
                modifier = Modifier
            )
            Text(
                text = from,
                fontSize = 16.sp,
                modifier = Modifier
                    .padding(16.dp)
            )
    }
}


//Per controllare in Design
@Preview(showBackground = true)
@Composable
fun MyCardPreview() {
    MyApplicationTheme {
        DisplayImages()
        GreetingText(message = "MyCard", from = "Simone Salvatore La Milia")
    }
}




@Composable
fun DisplayImages(modifier: Modifier = Modifier){
    var imageGit = painterResource(R.drawable.github_logo_png_github_logo_png_transparent_amp_svg_vector_pluspng_2400x2400_826714813)
    val imagePhone = painterResource(R.drawable.phone_png48988_4116668908)
    val imageMail = painterResource(R.drawable.email_svg_icon_5_2737624546)

        Image(
            painter = painterResource(R.drawable.papers),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
        )
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            GreetingIcon(imageGit, "BruceZZSeventy-Seven")
        }
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.Start
        ) {
            GreetingIcon(imagePhone, "+00 1111222233")
        }
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            GreetingIcon(imageMail, "simone.la101@ulpgc")
        }
    }



@Composable
fun GreetingIcon(image: Painter, message: String){
    Image(
        painter = image,
        contentDescription = null,
        modifier = Modifier
            .padding(16.dp)
            .height(70.dp)
            .width(70.dp)
    )
    Text(
        text = message,
        fontSize = 15.sp,
        modifier = Modifier
    )
}

@Composable
fun GreetingImage(){
        Image(
            painter = painterResource(R.drawable.android_logo),
            contentDescription = null,
            modifier = Modifier
                .padding(16.dp)
                .height(200.dp)
                .width(200.dp)
        )
}


