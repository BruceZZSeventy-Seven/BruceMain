#-----Import-----

import search
import time


#-----Graphic Interface----
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from random import *


#-----------Method---------

def cmdResult():
    start = cmbSnodes.get()
    end = cmbEnodes.get()
    
    if start and end:
        ab = search.GPSProblem(start, end
                        , search.romania)
        bf_time_I = time.time_ns()
        for i in range (1000):
            bf_node, bf_gen, bf_vis, bf_pt = search.breadth_first_graph_search(ab)
        bf_time_F = time.time_ns()
        df_time_I = time.time_ns()
        for i in range (1000):
            df_node, df_gen, df_vis, df_pt =search.depth_first_graph_search(ab)
        df_time_F = time.time_ns()
        bb_time_I = time.time_ns()
        for i in range (1000):
            bb_node, bb_gen, bb_vis, bb_pt =search.branch_and_bound_search(ab)
        bb_time_F = time.time_ns()
        bbe_time_I = time.time_ns()
        for i in range (1000):
            bbe_node, bbe_gen, bbe_vis, bbe_pt =search.branch_and_bound_with_subestimate_search(ab)
        bbe_time_F = time.time_ns()
        messagebox.showinfo(f"Results",
                            f"FROM {start} -- to --> {end}\n\n-BREADTH FIRST\nGenerated : {bf_gen}\nVisited : {bf_vis}\nCost: {bf_pt} \nResult : {bf_node.path()}\nTime after 1000 runs : {bf_time_F-bf_time_I} ns\n\n-DEPTH FIRST\nGenerated : {df_gen}\nVisited : {df_vis}\nCost: {df_pt}  \nResult : {df_node.path()}\nTime after 1000 runs : {df_time_F-df_time_I} ns\n\n-BRANCH AND BOUND\nGenerated : {bb_gen}\nVisited : {bb_vis}\nCost: {bb_pt}  \nResult : {bb_node.path()}\nTime after 1000 runs : {bb_time_F-bb_time_I} ns\n\n-B&B WITH SUBESTIMATE\nGenerated : {bbe_gen}\nVisited : {bbe_vis}\nCost: {bbe_pt}  \nResult : {bbe_node.path()}\nTime after 1000 runs : {bbe_time_F-bbe_time_I} ns\n")
    else:
        messagebox.showinfo("ATTENTION!", "You have to choose the two nodes!!!")  

def cmdAbout():
    messagebox.showinfo("Hi!","\nSimone Salvatore La Milia\nFSI Practica 1\nULPGC \nJanuary 2023")

def cmdBeB():
    messagebox.showinfo("Branch and Bound search","\nUninformed research\nThe queue is sorted by pathcost")

def cmdBeBwE():
    messagebox.showinfo("Branch and Bound with Subestimate search","\nInformed research\nThe queue is sorted by pathcost and heuristic")



#---------Screen--------

win=Tk() 
win.geometry('600x300')
win.title("Route search in the map of Romania")


#----------Menu---------
mn = Menu(win) 
win.config(menu=mn) 
file_menu = Menu(mn) 
mn.add_cascade(label='Info', menu=file_menu) 
file_menu.add_command(label='Branch and Bound', command=cmdBeB) 
file_menu.add_command(label='B&B with Subestimate', command=cmdBeBwE) 
file_menu.add_separator() 
file_menu.add_command(label='About', command=cmdAbout) 
file_menu.add_separator() 
file_menu.add_command(label='Close', command=win.quit) 


#---------Input Box and Parameters-------

gruppo = LabelFrame(win, text="FROM", padx=5, pady=5, width=300)
gruppo.grid(row=0, sticky='W', padx=5, pady=5, ipadx=5, ipady=5)
Label(gruppo, text="Select node:").grid(row=3, sticky=W)
Snodes = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Z"]
cmbSnodes= ttk.Combobox(gruppo, values=Snodes)
cmbSnodes.grid(row=3, column=1, sticky=W)


gruppo = LabelFrame(win, text="TO", padx=5, pady=5, width=300)
gruppo.grid(row=5, sticky='W', padx=5, pady=5, ipadx=5, ipady=5)
Label(gruppo, text="Select node:").grid(row=3, sticky=W)
Enodes = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Z"]
cmbEnodes= ttk.Combobox(gruppo, values=Enodes)
cmbEnodes.grid(row=3, column=1, sticky=W)


cmdResult    = Button(win, text='Result', command= cmdResult)
cmdQuit     = Button(win, text='Quit', command=win.quit)

cmdResult.grid(row=25, column=1, sticky=S+E)
cmdQuit.grid(row=25, column=6, sticky=S+E)



#----------Main--------

win.mainloop() 




'''
--------------OLD IMPLEMENTATION from the starter code------------

ab = search.GPSProblem('A', 'B'
                       , search.romania)



print(search.breadth_first_graph_search(ab).path())
print(search.depth_first_graph_search(ab).path())
print(search.branch_and_bound_search(ab).path())
print(search.branch_and_bound_with_subestimate_search(ab).path())

# Result:
# [<Node B>, <Node P>, <Node R>, <Node S>, <Node A>] : 101 + 97 + 80 + 140 = 418
# [<Node B>, <Node F>, <Node S>, <Node A>] : 211 + 99 + 140 = 450

'''
